# Copyright (c) 2023, Tiwiex and Contributors
# See license.txt

# import frappe
import unittest

class TestiDeltaInternetPackage(unittest.TestCase):
	pass
