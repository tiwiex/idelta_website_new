// Copyright (c) 2023, Tiwiex and contributors
// For license information, please see license.txt

frappe.ui.form.on('iDelta Internet Package', {
	// refresh: function(frm) {

	// }
});
