# Copyright (c) 2023, Tiwiex and Contributors
# See license.txt

# import frappe
import unittest

class TestPackageFeatureItem(unittest.TestCase):
	pass
